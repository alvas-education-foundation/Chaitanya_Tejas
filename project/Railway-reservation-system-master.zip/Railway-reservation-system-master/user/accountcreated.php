<?php include('header.php');
 require '../dbconnect.php';
 ?>
 <div align="center">
 <h2 style="margin:50px;color:whites">Welcome to the Club! Your sign up was succesful, please <a href="login.php" style="color:red">Login</a></h2>
 </div>
 <?php include('../footer.php'); ?>