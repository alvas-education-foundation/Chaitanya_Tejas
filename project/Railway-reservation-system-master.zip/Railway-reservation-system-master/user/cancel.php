<?php include('header.php'); ?>
			 
			  <div class="col-md-12 forminput">
			  
				
				<form  action="Ccancel.php" method="post" class="form-horizontal">
				
				  <div class="form-group">
					<label for="inputEmail3" class="col-sm-3 control-label">PNR number</label>
					<div class="col-sm-8">
					  <input type="text" class="form-control" id="inputEmail3" placeholder="pnr no." name="pnr">
					</div>
				  <br></br>
				  <br></br>
				  <div class="form-group">
				  
					<div class="col-sm-offset-3 col-sm-8">
					  <input type="submit" name="submit" value="Submit">
					</div>
				  </div>
				</form>
				
			  </div>
			  </div>
<?php include('../footer.php'); ?>
 

       