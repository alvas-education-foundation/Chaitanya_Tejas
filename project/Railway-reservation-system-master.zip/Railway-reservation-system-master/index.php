<?php include('header.php'); ?>
			 
			  <div class="col-md-12 ">
				<div class="slider">
					<img src="train2.gif" width="100%" />
				</div>
			  </div>

 

       